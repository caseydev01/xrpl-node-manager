package com.radynamics.xrplservermgr.ui.contentview;

public enum MenuItem {
    ServerStatus,
    Amendments,
    Configuration,
    Logs,
    Peers,
    Streams,
    CommandLine
}
