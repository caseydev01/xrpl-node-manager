package com.radynamics.xrplservermgr.sshapi.parser;

public enum Platform {
    Unknown,
    Debian,
    Fedora,
}
