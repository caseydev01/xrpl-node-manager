package com.radynamics.xrplservermgr.xrpl;

import java.net.URI;

public class Uris {
    private URI amendmentsOverview;

    public URI amendmentsOverview() {
        return amendmentsOverview;
    }

    public void amendmentsOverview(URI amendmentsOverview) {
        this.amendmentsOverview = amendmentsOverview;
    }
}
