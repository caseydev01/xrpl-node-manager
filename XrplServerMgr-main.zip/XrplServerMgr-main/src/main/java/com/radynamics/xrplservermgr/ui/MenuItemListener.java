package com.radynamics.xrplservermgr.ui;

import com.radynamics.xrplservermgr.ui.contentview.MenuItem;

public interface MenuItemListener {
    void onOpen(MenuItem item);
}
