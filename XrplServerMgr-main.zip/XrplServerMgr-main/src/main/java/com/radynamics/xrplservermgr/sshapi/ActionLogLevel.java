package com.radynamics.xrplservermgr.sshapi;

public enum ActionLogLevel {
    Info,
    Warning,
    Error,
}
