package com.radynamics.xrplservermgr.ui.logview;

public interface ChangedListener {
    void onChanged(String raw);
}
