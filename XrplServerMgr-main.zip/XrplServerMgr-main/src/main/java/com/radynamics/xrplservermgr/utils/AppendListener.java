package com.radynamics.xrplservermgr.utils;

import org.apache.logging.log4j.core.LogEvent;

// obsolete
public interface AppendListener {
    void onAppend(LogEvent event);
}
