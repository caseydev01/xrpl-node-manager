package com.radynamics.xrplservermgr.ui;

public interface FormActionListener {
    void onAccept();

    void onCancel();
}
