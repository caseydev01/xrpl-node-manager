package com.radynamics.xrplservermgr.ui;

public interface FilePathLabelListener {
    void onButtonClicked();
}
