package com.radynamics.xrplservermgr.ui;

public interface TabPage {
    void close();
}
