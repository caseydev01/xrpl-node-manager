package com.radynamics.xrplservermgr.sshapi;

public interface ActionLogListener {
    void onEvent(ActionLogEvent event);
}
