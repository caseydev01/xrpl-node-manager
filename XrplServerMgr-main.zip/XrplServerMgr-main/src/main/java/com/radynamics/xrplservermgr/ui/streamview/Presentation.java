package com.radynamics.xrplservermgr.ui.streamview;

import javax.swing.*;

public interface Presentation {
    JComponent view();
}
