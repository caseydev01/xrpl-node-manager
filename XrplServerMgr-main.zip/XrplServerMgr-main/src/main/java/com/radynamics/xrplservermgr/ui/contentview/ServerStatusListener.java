package com.radynamics.xrplservermgr.ui.contentview;

public interface ServerStatusListener {
    void onCloseAndReopenSession();
}
