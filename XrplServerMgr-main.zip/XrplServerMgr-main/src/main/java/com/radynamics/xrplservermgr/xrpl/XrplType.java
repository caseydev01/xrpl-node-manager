package com.radynamics.xrplservermgr.xrpl;

public enum XrplType {
    XrpLedger,
    Xahau
}
