package com.radynamics.xrplservermgr.ui.backgroundimage;

import java.awt.*;

public interface BackgroundImageListener {
    void onImageChanged(Image image);
}
